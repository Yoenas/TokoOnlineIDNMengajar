package com.yoenas.tokoonline.data.model.cart

import com.google.gson.annotations.SerializedName

data class ResponseCheckout(
    @SerializedName("msg") val msg: String
)
